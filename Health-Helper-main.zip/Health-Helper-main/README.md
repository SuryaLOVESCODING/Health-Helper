# Health-Helper
A app that has treatments for diseases, covid 19 map and their cases, health bots
